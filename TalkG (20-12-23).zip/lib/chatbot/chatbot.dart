//import '../main.dart';
import 'BardAIController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ChatBot extends StatelessWidget {
  const ChatBot({super.key});

  @override
  Widget build(BuildContext context) {
    BardAIController controller = Get.put(BardAIController());
    TextEditingController textField = TextEditingController();
    return Scaffold(
        backgroundColor: Color(0xfff2f1f9),
        appBar: AppBar(
          centerTitle: true,
          leading: Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("images/icon.png"), fit: BoxFit.fill),
              color: Colors.white,
              shape: BoxShape.circle,
            ),
          ),
          title: const Text(
            "TalkG",
            style: TextStyle(color: Colors.black),
          ),
          backgroundColor: Colors.white,
        ),
        body: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0XFF94bbe9), Color(0XFFeeaeca)])),
          child: Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(
              children: [
                Expanded(
                    child: ListView(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: EdgeInsets.symmetric(
                              vertical: 10, horizontal: 20),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            "Welcome to Chat Ai, Ask Something ❤️ ",
                            style: TextStyle(fontSize: 15.0),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 15),
                    Obx(() => Column(
                          children: controller.historyList
                              .map((e) => Row(
                                    mainAxisAlignment: e.system == "user"
                                        ? MainAxisAlignment.end
                                        : MainAxisAlignment.start,
                                    children: [
                                      Flexible(
                                          child: Container(
                                        padding: EdgeInsets.all(16),
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 16, vertical: 4),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.only(
                                                topLeft: Radius.circular(24),
                                                bottomRight: e.system == "user"
                                                    ? Radius.circular(0)
                                                    : Radius.circular(24),
                                                topRight: Radius.circular(24),
                                                bottomLeft: e.system == "user"
                                                    ? Radius.circular(24)
                                                    : Radius.circular(0)),
                                            color: e.system == "user"
                                                ? Color.fromARGB(
                                                    255, 234, 236, 240)
                                                : Color.fromARGB(
                                                    255, 211, 228, 243)),
                                        child: Text(
                                          e.message,
                                          style: TextStyle(
                                              color: Colors.black,
                                              fontSize: 15.0,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      )),
                                    ],
                                  ))
                              .toList(),
                        ))
                  ],
                )),
                Row(children: [
                  //input field & buttons
                  Expanded(
                      child: Card(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)),
                          child: Row(children: [
                            Padding(padding: EdgeInsets.only(left: 8.0)),
                            Expanded(
                                child: TextField(
                              controller: textField,
                              keyboardType: TextInputType.multiline,
                              //maxLines: 1,
                              decoration: const InputDecoration(
                                  hintText: 'Ask Something...',
                                  hintStyle: TextStyle(color: Colors.black),
                                  border: InputBorder.none),
                            )),
                            Obx(
                              () => controller.isLoading.value
                                  ? CircularProgressIndicator(
                                      color: Colors.black,
                                    )
                                  : //send message button
                                  MaterialButton(
                                      onPressed: () {
                                        if (textField.text != "") {
                                          controller.sendPrompt(textField.text);
                                          textField.clear();
                                        }
                                      },
                                      minWidth: 0,
                                      padding: const EdgeInsets.only(
                                          top: 10,
                                          bottom: 10,
                                          right: 5,
                                          left: 10),
                                      shape: const CircleBorder(),
                                      color: Colors.black,
                                      child: const Icon(Icons.send,
                                          color: Colors.white, size: 28),
                                    ),
                            ),
                          ])))
                ]),
                SizedBox(height: 60),
              ],
            ),
          ),
        ));
  }
}
