String APIKEY = "AIzaSyCm2NBNl8IYuKONji8FOwyQ02YLP15gjbY";
String BaseURL =
    "https://generativelanguage.googleapis.com/v1beta2/models/text-bison-001:generateText?key=YOUR_API_KEY";
