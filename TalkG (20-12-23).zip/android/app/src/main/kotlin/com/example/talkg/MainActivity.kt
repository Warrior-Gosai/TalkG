package com.example.talkg

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
